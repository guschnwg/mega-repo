###
# Declarando caminho, definições e pacotes
###

# Diretório do projeto, de onde serão salvos e lidos os arquivos
project_root_path <- paste0(getwd(), "/Aula 7")

###
# Variáveis e definições
###
source(paste0(project_root_path, "/definitions.R"))

###
# Instalando e carregando pacotes
###
source(paste0(project_root_path, "/install_load_packages.R"), encoding = encoding)

dados <- read.csv(paste0(project_root_path, "/yulu_bike_sharing_dataset.csv"))
summary(dados)
str(dados)

dados <- dados %>%
  dplyr::mutate(
    season_factor = factor(
      season,
      levels = c(2, 3, 4, 1),
      labels = c("Primavera", "Verão", "Outono", "Inverno")
    ),
    holiday_factor = factor(holiday,
      levels = c(0, 1),
      labels = c("Não", "Sim")
    ),
    workingday_factor = factor(workingday,
      levels = c(0, 1),
      labels = c("Não", "Sim")
    ),
    weather_factor = factor(weather,
      levels = c(1, 2, 3, 4),
      labels = c("Céu limpo/parcialmente numblado", "Névo + Nuvens", "Chuva/Neve level + trovoada", "Chuva forte + granizo + trovoada + névoa")
    ),
    dia = lubridate::as_date(datetime),
    hora = lubridate::hour(datetime),
    ano_mes = lubridate::floor_date(dia, "month"),
    hora_cat = factor(
      case_when(
        between(hora, 6, 9) ~ "Manhã ini",
        between(hora, 10, 11) ~ "Manhã",
        between(hora, 12, 13) ~ "Tarde ini",
        between(hora, 14, 16) ~ "Tarde",
        between(hora, 17, 20) ~ "Fim do dia",
        TRUE ~ "Noite/Madrugada"
      ),
      levels = c("Manhã ini", "Manhã", "Tarde ini", "Tarde", "Fim do dia", "Noite/Madrugada")
    )
  )


str(dados)
table(dados$hora_cat, dados$hora)

dados %>%
  dplyr::select(~ c(season, holiday, workingday, weather, datetime))

skimr::skim(dados)
