#####################
## DEFINIÇÕES
####################

# Encoding genérico para renderizações
encoding <- "UTF-8"
